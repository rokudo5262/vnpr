<?php
$settings = array( 'media_buttons' => false );
wp_editor( $value, $field_id, $settings );