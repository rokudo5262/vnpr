<?php 
    $message = isset( $field['message'] ) ? $field['message'] : '';
?>

<div class="nx-info-message">
    <?php echo $message; ?>
</div>