<?php

    $class .= ' nx-colorpicker-field';

?>

<input type="text" id="<?php echo $field_id; ?>" name="<?php echo $name; ?>" class="<?php echo $class; ?>" value="<?php echo $value; ?>" <?php echo $attrs; ?>/>