=== WP Events Importer ===
Contributors: ugurbicer,[bulut wp hesabı]
Tags: facebook, meetup, eventbrite, ical, xml
Requires at least: 4.9
Tested up to: 5.2.2
Stable tag: 1.3.1
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires PHP: 5.6.5

WP Events Importer

== Description ==
WP Events Importer

Features :

= Facebook =


= Meetup =


= Eventbrite =


= Ical =


= XML =


== Installation ==

1. Download and unzip the plugin into your WordPress plugins directory (usually `/wp-content/plugins/`).
2. Activate the plugin through the `Plugins` menu in your WordPress Admin.
3. Go to the Plugin`s settings page and then it`s up to you.

== Screenshots ==

1. General Settings page
2. Facebook connection settings
3. Eventbrite connection settings
3. Meetup connection settings
4. Single Import
5. Multiple Import

== Frequently Asked Questions ==

If you have any question, you can post [a support request](https://wordpress.org/support/plugin/wpeventsimporter/)


== Changelog ==

= 1.1.0 =
* WP Events Importer Released.


See more info ![GloriaThemes](http://gloriathemes.com)
